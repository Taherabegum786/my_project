Post-Quantum Access Tokens for CDNs: Stapling Fixes the Edge, Pooled Batching Fixes the Issuer
LaTeX source (IEEEtran journal class, included).

Build:  pdflatex main && bibtex main && pdflatex main && pdflatex main
   or:  latexmk -pdf main.tex
Overleaf: upload this zip as a new project; main.tex is the root file.

Before submission, fill the placeholders marked [Editable] (author block,
data availability URL, AI-use declaration, acknowledgment).
